# AeroGram – Telegram fork (Audio / Video calls)
Official Telegram Android (DrKLO) source build করে, build-এর সময় নিজে patch করে:
- আলাদা ID: `org.aerogram.audio` / `org.aerogram.video` (পাশাপাশি install হয়)
- আপনার `api_id`/`api_hash`, নাম "AeroGram"
- **audio**: video call শুরু করার পথ বন্ধ (`VoIPHelper.startCall`), **video**: audio+video দুটোই
- Universal (fat) APK: arm64-v8a, armeabi-v7a, x86, x86_64

## Setup
1. এই ফাইলগুলো GitHub repo-র root-এ push করুন।
2. Settings → Secrets → Actions: `TG_API_ID`, `TG_API_HASH` (বাধ্যতামূলক)।
   ঐচ্ছিক: `GOOGLE_SERVICES_JSON`, `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`।
3. Actions → Run workflow → `video` / `audio` / `both`।
4. APK পাবেন Releases-এ। (keystore না দিলে auto-generated key দিয়ে sign হয়; আপডেটের জন্য নিজের keystore দিন।)

## জানা সীমাবদ্ধতা
- Patch regex-ভিত্তিক; upstream কাঠামো বদলালে build ইচ্ছাকৃতভাবে fail করবে।
- audio variant-এ বাটন UI-তে থেকে যেতে পারে, চাপলে audio call হবে। অন্যের পাঠানো incoming video call আলাদাভাবে block করা হয়নি।
- google-services.json ছাড়া background push notification নির্ভরযোগ্য নাও হতে পারে।
- GPLv2: source খোলা রাখতে হবে, Telegram-এর নাম/লোগো ব্যবহার করবেন না, "unofficial" উল্লেখ রাখুন।
- Build ~১-২ ঘণ্টা লাগতে পারে।
