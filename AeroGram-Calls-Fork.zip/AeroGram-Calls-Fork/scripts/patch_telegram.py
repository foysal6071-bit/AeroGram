#!/usr/bin/env python3
"""Telegram Android (DrKLO) source patcher. env: VARIANT(audio|video) APP_ID APP_HASH APP_NAME [SRC=Telegram]
কোনো pattern না মিললে build fail করবে (যাতে চুপচাপ unpatched APK না বের হয়)।"""
import os, re, sys, pathlib

SRC = pathlib.Path(os.environ.get("SRC", "Telegram"))
V = os.environ["VARIANT"]
APP_ID = os.environ["APP_ID"]
APP_HASH = os.environ["APP_HASH"]
APP_NAME = os.environ.get("APP_NAME", "AeroGram")
assert V in ("audio", "video"), V
assert APP_ID.isdigit(), "APP_ID must be a number"

def sub_file(path, pattern, repl, flags=0, required=True):
    p = SRC / path
    if not p.exists():
        if required: sys.exit(f"FAIL: {path} not found")
        return 0
    t = p.read_text(encoding="utf-8")
    t2, n = re.subn(pattern, repl, t, flags=flags)
    if n == 0 and required: sys.exit(f"FAIL: pattern not found in {path}: {pattern}")
    if n: p.write_text(t2, encoding="utf-8")
    print(f"ok  {path}: {n} change(s)")
    return n

# 1) আলাদা applicationId (audio/video পাশাপাশি install হবে)
n = 0
for g in ("TMessagesProj_AppStandalone/build.gradle", "TMessagesProj_AppStandalone/build.gradle.kts",
          "TMessagesProj/build.gradle", "TMessagesProj/build.gradle.kts"):
    n += sub_file(g, r'applicationId(\s*=?\s*)["\'][^"\']+["\']',
                  lambda m: f'applicationId{m.group(1)}"org.aerogram.{V}"', required=False)
if n == 0: sys.exit("FAIL: applicationId not found in any gradle file")

# 2) নিজের API credentials
B = "TMessagesProj/src/main/java/org/telegram/messenger/BuildVars.java"
sub_file(B, r'APP_ID\s*=\s*\d+\s*;', f'APP_ID = {APP_ID};')
sub_file(B, r'APP_HASH\s*=\s*"[^"]*"\s*;', f'APP_HASH = "{APP_HASH}";')

# 3) App নাম
sub_file("TMessagesProj/src/main/res/values/strings.xml",
         r'(<string name="AppName"[^>]*>)[^<]*(</string>)', lambda m: m.group(1) + APP_NAME + m.group(2))

# 4) Audio-only: video call শুরু করার সব পথ VoIPHelper.startCall-এ বন্ধ
if V == "audio":
    p = "TMessagesProj/src/main/java/org/telegram/messenger/voip/VoIPHelper.java"
    sig = re.compile(r'(static\s+void\s+startCall\s*\([^)]*boolean\s+videoCall[^)]*\)\s*(?:throws[^{]*)?\{)')
    text = (SRC / p).read_text(encoding="utf-8")
    def ins(m):
        extra = " canVideoCall = false;" if "canVideoCall" in m.group(1) else ""
        return m.group(1) + "\n        videoCall = false;" + extra + " // AeroGram audio-only"
    text2, n = sig.subn(ins, text)
    if n == 0: sys.exit("FAIL: VoIPHelper.startCall(videoCall) not found - source structure changed")
    (SRC / p).write_text(text2, encoding="utf-8")
    print(f"ok  {p}: {n} startCall overload(s) forced audio-only")
print("PATCH DONE:", V)
