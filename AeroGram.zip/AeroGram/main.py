"""
AeroGram - simple Telegram client (imo lite style)
Run:  pip install telethon flask
      python tg_lite.py
Open: http://127.0.0.1:5000  (phone browser or PC)

Get API_ID and API_HASH free from https://my.telegram.org
"""
import asyncio
import json
import os
import threading

from flask import Flask, jsonify, render_template_string, request
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError

DATA = os.environ.get("ANDROID_PRIVATE") or os.path.dirname(os.path.abspath(__file__))
CRED = os.path.join(DATA, "creds.json")
SESSION = os.path.join(DATA, "aerogram_session")

loop = asyncio.new_event_loop()
threading.Thread(target=loop.run_forever, daemon=True).start()


def run(coro):
    return asyncio.run_coroutine_threadsafe(coro, loop).result(60)


client = None
state = {"phone": None, "hash": None}


def get_client():
    global client
    if client is None and os.path.exists(CRED):
        c = json.load(open(CRED))

        async def _make():
            cl = TelegramClient(SESSION, int(c["id"]), c["hash"])
            await cl.connect()
            return cl
        client = run(_make())
    return client


app = Flask(__name__)


@app.get("/api/status")
def status():
    c = get_client()
    if not c:
        return jsonify(configured=False)
    return jsonify(configured=True, authorized=run(c.is_user_authorized()))


@app.post("/api/creds")
def creds():
    d = request.json
    try:
        int(d["id"])
        json.dump({"id": d["id"], "hash": d["hash"].strip()}, open(CRED, "w"))
    except Exception as e:
        return jsonify(error=str(e)), 400
    return jsonify(ok=True)


@app.post("/api/send_code")
def send_code():
    phone = request.json["phone"].strip()
    try:
        res = run(get_client().send_code_request(phone))
    except Exception as e:
        return jsonify(error=str(e)), 400
    state.update(phone=phone, hash=res.phone_code_hash)
    kind = type(res.type).__name__
    return jsonify(ok=True, app=("App" in kind), kind=kind)


@app.post("/api/login")
def login():
    d = request.json
    try:
        if d.get("password") and not d.get("code"):
            run(get_client().sign_in(password=d["password"]))
        else:
            run(get_client().sign_in(state["phone"], d["code"].strip(),
                               phone_code_hash=state["hash"]))
    except SessionPasswordNeededError:
        return jsonify(need_password=True)
    except Exception as e:
        return jsonify(error=str(e)), 400
    return jsonify(ok=True)


@app.get("/api/me")
def me():
    try:
        u = run(get_client().get_me())
        return jsonify(name=((u.first_name or "") + " " + (u.last_name or "")).strip() or "Me")
    except Exception as e:
        return jsonify(error=str(e)), 400


@app.get("/api/chats")
def chats():
    async def go():
        out = []
        async for d in get_client().iter_dialogs(limit=60):
            m = d.message
            out.append({
                "id": d.id,
                "name": d.name or "Unknown",
                "unread": d.unread_count,
                "last": (m.message if m and m.message else "[media]") if m else "",
            })
        return out
    return jsonify(run(go()))


@app.get("/api/messages/<int:cid>")
def messages(cid):
    async def go():
        msgs = await get_client().get_messages(cid, limit=40)
        await get_client().send_read_acknowledge(cid)
        return [{"id": m.id, "out": bool(m.out),
                 "text": m.message or "[media]",
                 "time": m.date.astimezone().strftime("%H:%M")}
                for m in reversed(msgs)]
    try:
        return jsonify(run(go()))
    except Exception as e:
        return jsonify(error=str(e)), 400


@app.post("/api/send")
def send():
    d = request.json
    try:
        run(get_client().send_message(int(d["chat"]), d["text"]))
    except Exception as e:
        return jsonify(error=str(e)), 400
    return jsonify(ok=True)


@app.post("/api/logout")
def logout():
    run(get_client().log_out())
    return jsonify(ok=True)


@app.get("/")
def index():
    return render_template_string(PAGE)


PAGE = r"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#1f2025">
<title>AeroGram</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font-family:system-ui,sans-serif;background:#1f2025;color:#fff}
#app{max-width:520px;margin:auto;height:100vh;display:flex;flex-direction:column;background:#1f2025}
button{font-family:inherit}
#top{display:none;align-items:stretch;border-bottom:1px solid #33353b;background:#1f2025}
#me{width:56px;flex:none;background:none;border:0;padding:8px 10px}
#me .av{width:36px;height:36px;font-size:15px}
#tabs{flex:1;display:flex;overflow-x:auto;scrollbar-width:none}
#tabs::-webkit-scrollbar{display:none}
.tab{flex:none;display:flex;align-items:center;gap:6px;padding:0 16px;max-width:150px;background:none;border:0;border-bottom:3px solid transparent;color:#9a9ca3;font-size:15px;position:relative}
.tab.on{color:#0a9bff;border-bottom-color:#0a9bff}
.tab span.t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tab .x{font-size:18px;line-height:1;padding:4px;color:#9a9ca3}
.badge{background:#3dbb4f;color:#fff;border-radius:10px;font-size:11px;min-width:18px;height:18px;padding:0 5px;display:inline-flex;align-items:center;justify-content:center}
#addtab{flex:none;width:52px;background:none;border:0;color:#0a9bff;font-size:30px;font-weight:300}
.view{flex:1;overflow-y:auto;display:none}
.chat{display:flex;gap:14px;padding:12px 14px;cursor:pointer;align-items:center}
.chat .info{border-bottom:1px solid #33353b;padding-bottom:12px}
.av{width:52px;height:52px;border-radius:50%;background:#3a3d45;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;flex:none}
.info{flex:1;min-width:0}.nm{font-weight:600;font-size:17px}.ls{color:#9a9ca3;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#msgs{padding:10px;background:#1a1b1f}
.m{max-width:78%;padding:8px 12px;border-radius:14px;margin:4px 0;white-space:pre-wrap;word-wrap:break-word}
.m.in{background:#2e3037;margin-right:auto}.m.out{background:#0a7fd6;margin-left:auto}
.m small{display:block;color:#c0c4cc;font-size:11px;text-align:right}
#bar{display:none;padding:8px;gap:8px;border-top:1px solid #33353b}
#bar input{flex:1;padding:12px;border:1px solid #3a3d45;background:#2a2c32;color:#fff;border-radius:20px;font-size:16px}
#bar button,.btn{background:#0a7fd6;color:#fff;border:0;border-radius:20px;padding:0 18px;font-size:16px}
#bottom{display:none;align-items:center;justify-content:space-between;padding:6px 18px;border-top:1px solid #33353b;gap:10px}
#bottom button{background:none;border:0;color:#0a9bff;font-size:30px;font-weight:300;padding:4px 8px}
#q{display:none;flex:1;padding:10px 14px;border:1px solid #3a3d45;background:#2a2c32;color:#fff;border-radius:20px;font-size:16px}
#picker{position:fixed;inset:0;background:rgba(0,0,0,.6);display:none;z-index:9}
#picker .box{max-width:520px;margin:auto;height:100%;background:#1f2025;display:flex;flex-direction:column}
#picker .hd{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid #33353b;font-weight:600}
#picker .hd button{background:none;border:0;color:#0a9bff;font-size:16px}
#picker input{flex:1;padding:10px 14px;border:1px solid #3a3d45;background:#2a2c32;color:#fff;border-radius:20px;font-size:16px}
#plist{flex:1;overflow-y:auto}
.setup,#login{padding:30px;text-align:center}
.setup input,#login input{width:100%;padding:12px;margin:8px 0;font-size:16px;border:1px solid #3a3d45;border-radius:8px;background:#2a2c32;color:#fff}
.setup .btn,#login .btn{width:100%;padding:12px;border-radius:8px}#err{color:#ff6b6b;margin-top:10px}
</style></head><body><div id="app">
<div id="top"><button id="me" onclick="logout()" title="Logout"><div class="av" id="meav">?</div></button>
<div id="tabs"></div><button id="addtab" onclick="openPicker()">+</button></div>
<div id="setup" class="view setup"><h3>API Setup</h3><input id="aid" placeholder="api_id"><input id="ah" placeholder="api_hash"><button class="btn" onclick="saveCreds()">Save</button></div>
<div id="login" class="view"><h3>Telegram Login</h3>
<div id="s1"><input id="phone" placeholder="+8801XXXXXXXXX" type="tel"><button class="btn" onclick="sendCode()">Code pathan</button></div>
<div id="s2" style="display:none"><div id="how" style="color:#9a9ca3;margin-bottom:6px"></div><input id="code" placeholder="Login code"><button class="btn" onclick="login()">Login</button><button class="btn" style="margin-top:10px;background:none;color:#0a9bff" onclick="sendCode()">Code abar pathan</button></div>
<div id="s3" style="display:none"><input id="pw" type="password" placeholder="2FA password"><button class="btn" onclick="login2()">Login</button></div>
<div id="err"></div></div>
<div id="list" class="view"></div>
<div id="msgs" class="view"></div>
<div id="bar"><input id="txt" placeholder="Message..." onkeydown="if(event.key==='Enter')send()"><button onclick="send()">&#10148;</button></div>
<div id="bottom"><button onclick="openPicker()">+</button><input id="q" placeholder="Search..." oninput="renderList()"><button onclick="toggleSearch()">&#9906;</button></div>
</div>
<div id="picker"><div class="box"><div class="hd"><button onclick="closePicker()">&larr;</button><input id="pq" placeholder="Profile select korun..." oninput="renderPicker()"></div><div id="plist"></div></div></div>
<script>
let cur=null,timer=null,chats=[],tabs=[],active='list';
const $=id=>document.getElementById(id);
async function api(p,b){const r=await fetch(p,b?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}:{});return r.json();}
function err(t){$('err').textContent=t||''}
function show(v){['setup','login','list','msgs'].forEach(x=>$(x).style.display=x===v?'block':'none');
 const inApp=v==='list'||v==='msgs';
 $('top').style.display=inApp?'flex':'none';$('bar').style.display=v==='msgs'?'flex':'none';
 $('bottom').style.display=v==='list'?'flex':'none';}
async function init(){const s=await api('/api/status');if(!s.configured)return show('setup');
 if(!s.authorized)return show('login');
 api('/api/me').then(r=>{if(r.name)$('meav').textContent=r.name[0].toUpperCase();});showList();}
async function saveCreds(){const r=await api('/api/creds',{id:$('aid').value,hash:$('ah').value});if(r.error)return alert(r.error);init();}
async function sendCode(){const r=await api('/api/send_code',{phone:$('phone').value});
 if(r.error)return err(r.error);err();$('s1').style.display='none';$('s2').style.display='block';
 $('how').textContent=r.app?'Code apnar Telegram app e (Telegram naam er chat e) pathano hoyeche':'Code SMS e pathano hoyeche (onno kono device e Telegram login thakle app e jay)';}
async function login(){const r=await api('/api/login',{code:$('code').value});
 if(r.error)return err(r.error);if(r.need_password){$('s2').style.display='none';$('s3').style.display='block';return;}init();}
async function login2(){const r=await api('/api/login',{password:$('pw').value});if(r.error)return err(r.error);init();}
async function logout(){if(!confirm('Logout korben?'))return;await api('/api/logout',{});location.reload();}
function avatar(n){const a=document.createElement('div');a.className='av';a.textContent=(n[0]||'?').toUpperCase();return a;}
function renderTabs(){const el=$('tabs');el.textContent='';
 const unread=chats.reduce((s,c)=>s+(c.unread||0),0);
 const t0=document.createElement('button');t0.className='tab'+(active==='list'?' on':'');
 const l=document.createElement('span');l.className='t';l.textContent='Chats';t0.append(l);
 if(unread){const b=document.createElement('span');b.className='badge';b.textContent=unread;t0.append(b);}
 t0.onclick=showList;el.append(t0);
 tabs.forEach(t=>{const b=document.createElement('button');b.className='tab'+(active===t.id?' on':'');
  const n=document.createElement('span');n.className='t';n.textContent=t.name;
  const x=document.createElement('span');x.className='x';x.textContent='\u00d7';
  x.onclick=e=>{e.stopPropagation();closeTab(t.id);};
  b.append(n,x);b.onclick=()=>openChat(t.id,t.name);el.append(b);});}
function closeTab(id){tabs=tabs.filter(t=>t.id!==id);if(active===id)showList();else renderTabs();}
function row(x,onclick){const d=document.createElement('div');d.className='chat';d.onclick=onclick;
 const i=document.createElement('div');i.className='info';
 const n=document.createElement('div');n.className='nm';n.textContent=x.name;
 const l=document.createElement('div');l.className='ls';l.textContent=x.last;
 i.append(n,l);d.append(avatar(x.name),i);
 if(x.unread){const u=document.createElement('span');u.className='badge';u.textContent=x.unread;d.append(u);}
 return d;}
function renderList(){const q=$('q').value.toLowerCase();const el=$('list');el.textContent='';
 chats.filter(c=>c.name.toLowerCase().includes(q)).forEach(x=>el.append(row(x,()=>openChat(x.id,x.name))));}
async function loadList(){const c=await api('/api/chats');if(!Array.isArray(c))return;chats=c;renderTabs();if(active==='list')renderList();}
function toggleSearch(){const q=$('q');const on=q.style.display!=='block';q.style.display=on?'block':'none';
 if(on)q.focus();else{q.value='';renderList();}}
function openPicker(){$('pq').value='';$('picker').style.display='block';renderPicker();}
function closePicker(){$('picker').style.display='none';}
function renderPicker(){const q=$('pq').value.toLowerCase();const el=$('plist');el.textContent='';
 chats.filter(c=>c.name.toLowerCase().includes(q)).forEach(x=>el.append(row(x,()=>{closePicker();openChat(x.id,x.name);})));}
function showList(){clearInterval(timer);cur=null;active='list';show('list');renderTabs();renderList();loadList();timer=setInterval(loadList,5000);}
async function loadMsgs(){if(!cur)return;const m=await api('/api/messages/'+cur);if(m.error)return;
 const el=$('msgs');const atEnd=el.scrollHeight-el.scrollTop-el.clientHeight<80;el.textContent='';
 m.forEach(x=>{const d=document.createElement('div');d.className='m '+(x.out?'out':'in');
  d.textContent=x.text;const s=document.createElement('small');s.textContent=x.time;d.append(s);el.append(d);});
 if(atEnd)el.scrollTop=el.scrollHeight;}
async function openChat(id,name){clearInterval(timer);cur=id;active=id;
 if(!tabs.find(t=>t.id===id))tabs.push({id,name});
 show('msgs');renderTabs();$('msgs').textContent='';
 await loadMsgs();$('msgs').scrollTop=$('msgs').scrollHeight;timer=setInterval(loadMsgs,3000);}
async function send(){const t=$('txt').value.trim();if(!t||!cur)return;$('txt').value='';
 await api('/api/send',{chat:cur,text:t});await loadMsgs();$('msgs').scrollTop=$('msgs').scrollHeight;}
init();
</script></body></html>"""

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), threaded=True)
