"""
AeroGram - simple Telegram client (imo lite style)
Run:  pip install telethon flask
      python tg_lite.py
Open: http://127.0.0.1:5000  (phone browser or PC)

Get API_ID and API_HASH free from https://my.telegram.org
"""
import asyncio
import json
import os
import threading

from flask import Flask, jsonify, render_template_string, request
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError

DATA = os.environ.get("ANDROID_PRIVATE") or os.path.dirname(os.path.abspath(__file__))
CRED = os.path.join(DATA, "creds.json")
SESSION = os.path.join(DATA, "aerogram_session")

loop = asyncio.new_event_loop()
threading.Thread(target=loop.run_forever, daemon=True).start()


def run(coro):
    return asyncio.run_coroutine_threadsafe(coro, loop).result(60)


client = None
state = {"phone": None, "hash": None}


def get_client():
    global client
    if client is None and os.path.exists(CRED):
        c = json.load(open(CRED))

        async def _make():
            cl = TelegramClient(SESSION, int(c["id"]), c["hash"])
            await cl.connect()
            return cl
        client = run(_make())
    return client


app = Flask(__name__)


@app.get("/api/status")
def status():
    c = get_client()
    if not c:
        return jsonify(configured=False)
    return jsonify(configured=True, authorized=run(c.is_user_authorized()))


@app.post("/api/creds")
def creds():
    d = request.json
    try:
        int(d["id"])
        json.dump({"id": d["id"], "hash": d["hash"].strip()}, open(CRED, "w"))
    except Exception as e:
        return jsonify(error=str(e)), 400
    return jsonify(ok=True)


@app.post("/api/send_code")
def send_code():
    phone = request.json["phone"].strip()
    try:
        res = run(get_client().send_code_request(phone))
    except Exception as e:
        return jsonify(error=str(e)), 400
    state.update(phone=phone, hash=res.phone_code_hash)
    return jsonify(ok=True)


@app.post("/api/login")
def login():
    d = request.json
    try:
        if d.get("password") and not d.get("code"):
            run(get_client().sign_in(password=d["password"]))
        else:
            run(get_client().sign_in(state["phone"], d["code"].strip(),
                               phone_code_hash=state["hash"]))
    except SessionPasswordNeededError:
        return jsonify(need_password=True)
    except Exception as e:
        return jsonify(error=str(e)), 400
    return jsonify(ok=True)


@app.get("/api/chats")
def chats():
    async def go():
        out = []
        async for d in get_client().iter_dialogs(limit=60):
            m = d.message
            out.append({
                "id": d.id,
                "name": d.name or "Unknown",
                "unread": d.unread_count,
                "last": (m.message if m and m.message else "[media]") if m else "",
            })
        return out
    return jsonify(run(go()))


@app.get("/api/messages/<int:cid>")
def messages(cid):
    async def go():
        msgs = await get_client().get_messages(cid, limit=40)
        await get_client().send_read_acknowledge(cid)
        return [{"id": m.id, "out": bool(m.out),
                 "text": m.message or "[media]",
                 "time": m.date.astimezone().strftime("%H:%M")}
                for m in reversed(msgs)]
    try:
        return jsonify(run(go()))
    except Exception as e:
        return jsonify(error=str(e)), 400


@app.post("/api/send")
def send():
    d = request.json
    try:
        run(get_client().send_message(int(d["chat"]), d["text"]))
    except Exception as e:
        return jsonify(error=str(e)), 400
    return jsonify(ok=True)


@app.post("/api/logout")
def logout():
    run(get_client().log_out())
    return jsonify(ok=True)


@app.get("/")
def index():
    return render_template_string(PAGE)


PAGE = r"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#1b4a96">
<title>AeroGram</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:system-ui,sans-serif;background:#e9eef7;color:#1c1e21}
#app{max-width:520px;margin:auto;height:100vh;display:flex;flex-direction:column;background:#fff}
header{background:linear-gradient(135deg,#4b7ac2,#1b4a96);color:#fff;padding:14px;display:flex;align-items:center;gap:10px;font-weight:600}
header button{background:none;border:0;color:#fff;font-size:18px}
header .sp{flex:1}
.view{flex:1;overflow-y:auto;display:none}
.chat{display:flex;gap:12px;padding:12px;border-bottom:1px solid #eee;cursor:pointer;align-items:center}
.av{width:44px;height:44px;border-radius:50%;background:#2a5aab;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;flex:none}
.info{flex:1;min-width:0}.nm{font-weight:600}.ls{color:#777;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.un{background:#2a5aab;color:#fff;border-radius:12px;padding:2px 8px;font-size:12px}
#msgs{padding:10px;background:#e6edf8}
.m{max-width:78%;padding:8px 12px;border-radius:14px;margin:4px 0;white-space:pre-wrap;word-wrap:break-word}
.m.in{background:#fff;margin-right:auto}.m.out{background:#cfe0f7;margin-left:auto}
.m small{display:block;color:#888;font-size:11px;text-align:right}
#bar{display:none;padding:8px;gap:8px;border-top:1px solid #ddd}
#bar input{flex:1;padding:12px;border:1px solid #ccc;border-radius:20px;font-size:16px}
#bar button,.btn{background:#2a5aab;color:#fff;border:0;border-radius:20px;padding:0 18px;font-size:16px}
#login{padding:30px;text-align:center}#login input{width:100%;padding:12px;margin:8px 0;font-size:16px;border:1px solid #ccc;border-radius:8px}
#login .btn{width:100%;padding:12px;border-radius:8px}#err{color:#d33;margin-top:10px}
</style></head><body><div id="app">
<header><button id="back" style="display:none" onclick="showList()">&larr;</button><span id="title">AeroGram</span><span class="sp"></span><button id="out" style="display:none" onclick="logout()">&#x23FB;</button></header>
<div id="setup" class="view" style="padding:30px;text-align:center"><h3>API Setup</h3><input id="aid" placeholder="api_id" style="width:100%;padding:12px;margin:8px 0;font-size:16px"><input id="ah" placeholder="api_hash" style="width:100%;padding:12px;margin:8px 0;font-size:16px"><button class="btn" style="width:100%;padding:12px" onclick="saveCreds()">Save</button></div>
<div id="login" class="view"><h3>Telegram Login</h3>
<div id="s1"><input id="phone" placeholder="+8801XXXXXXXXX"><button class="btn" onclick="sendCode()">Code pathan</button></div>
<div id="s2" style="display:none"><input id="code" placeholder="Login code"><button class="btn" onclick="login()">Login</button></div>
<div id="s3" style="display:none"><input id="pw" type="password" placeholder="2FA password"><button class="btn" onclick="login2()">Login</button></div>
<div id="err"></div></div>
<div id="list" class="view"></div>
<div id="msgs" class="view"></div>
<div id="bar"><input id="txt" placeholder="Message..." onkeydown="if(event.key==='Enter')send()"><button onclick="send()">&#10148;</button></div>
</div><script>
let cur=null,timer=null;
const $=id=>document.getElementById(id);
async function api(p,b){const r=await fetch(p,b?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}:{});return r.json();}
function err(t){$('err').textContent=t||''}
function show(v){['setup','login','list','msgs'].forEach(x=>$(x).style.display=x===v?'block':'none');
 $('bar').style.display=v==='msgs'?'flex':'none';$('back').style.display=v==='msgs'?'':'none';
 $('out').style.display=(v==='login'||v==='setup')?'none':'';}
async function init(){const s=await api('/api/status');if(!s.configured)return show('setup');s.authorized?showList():show('login');}
async function saveCreds(){const r=await api('/api/creds',{id:$('aid').value,hash:$('ah').value});if(r.error)return alert(r.error);init();}
async function sendCode(){const r=await api('/api/send_code',{phone:$('phone').value});
 if(r.error)return err(r.error);err();$('s1').style.display='none';$('s2').style.display='block';}
async function login(){const r=await api('/api/login',{code:$('code').value});
 if(r.error)return err(r.error);if(r.need_password){$('s2').style.display='none';$('s3').style.display='block';return;}showList();}
async function login2(){const r=await api('/api/login',{password:$('pw').value});if(r.error)return err(r.error);showList();}
async function logout(){await api('/api/logout',{});location.reload();}
async function loadList(){const c=await api('/api/chats');const el=$('list');el.textContent='';
 c.forEach(x=>{const d=document.createElement('div');d.className='chat';d.onclick=()=>openChat(x.id,x.name);
  const a=document.createElement('div');a.className='av';a.textContent=(x.name[0]||'?').toUpperCase();
  const i=document.createElement('div');i.className='info';
  const n=document.createElement('div');n.className='nm';n.textContent=x.name;
  const l=document.createElement('div');l.className='ls';l.textContent=x.last;
  i.append(n,l);d.append(a,i);
  if(x.unread){const u=document.createElement('span');u.className='un';u.textContent=x.unread;d.append(u);}
  el.append(d);});}
function showList(){clearInterval(timer);cur=null;$('title').textContent='AeroGram';show('list');loadList();timer=setInterval(loadList,5000);}
async function loadMsgs(){if(!cur)return;const m=await api('/api/messages/'+cur);if(m.error)return;
 const el=$('msgs');const atEnd=el.scrollHeight-el.scrollTop-el.clientHeight<80;el.textContent='';
 m.forEach(x=>{const d=document.createElement('div');d.className='m '+(x.out?'out':'in');
  d.textContent=x.text;const s=document.createElement('small');s.textContent=x.time;d.append(s);el.append(d);});
 if(atEnd)el.scrollTop=el.scrollHeight;}
async function openChat(id,name){clearInterval(timer);cur=id;$('title').textContent=name;show('msgs');
 await loadMsgs();$('msgs').scrollTop=$('msgs').scrollHeight;timer=setInterval(loadMsgs,3000);}
async function send(){const t=$('txt').value.trim();if(!t||!cur)return;$('txt').value='';
 await api('/api/send',{chat:cur,text:t});await loadMsgs();$('msgs').scrollTop=$('msgs').scrollHeight;}
init();
</script></body></html>"""

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), threaded=True)
